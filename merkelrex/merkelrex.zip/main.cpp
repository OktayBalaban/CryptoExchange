﻿#include "Wallet.h"
#include <iostream>
#include "MerkelMain.h"

int main()
{
    MerkelMain app{};
    app.init();

}
